<?php

namespace Aaqib\UniqueStringGenerator;

class UniqueStringGenerator
{
    // Build your next great package.
}
